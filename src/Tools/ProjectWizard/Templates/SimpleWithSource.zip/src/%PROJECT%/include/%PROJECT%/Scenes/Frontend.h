#pragma once

#include "AtlasScene/Scene.h"

namespace %PROJECTLOWER%::scenes
{
    class Frontend : public atlas::scene::EcsScene
    {
    public:
        void OnEntered(atlas::scene::SceneManager& sceneManager) override;
        void ConstructSystems(atlas::scene::SystemsBuilder& builder, atlas::scene::SystemsBuilder& frameBuilder) override;
    };
}