app "%PROJECT%"
	kind "WindowedApp"
    links {
        "AtlasAppHost",
        "AtlasGame",
        "AtlasScene",
        "AtlasResource",
        "AtlasRender",
    }
    generateCoreComponentRegistry("%PROJECTLOWER%", { 'engine', '%PROJECTLOWER%' });
