app "%PROJECT%"
	kind "WindowedApp"
    links {
        "AtlasAppHost",
        "AtlasGame",
        "AtlasScene",
        "AtlasResource",
        "AtlasRender",

        "%PROJECT%Assets",
        "%PROJECT%Common",
        "%PROJECT%StateFrontend",
    }
    generateCoreComponentRegistry("%PROJECTLOWER%", { 'engine', '%PROJECTLOWER%' });
