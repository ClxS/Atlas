#include "%PROJECT%PCH.h"

#include "Registry.h"
#include "AtlasGame/GameHost.h"
#include "AtlasRender/AssetTypes/ModelAsset.h"
#include "AtlasRender/AssetTypes/ShaderAsset.h"
#include "AtlasRender/AssetTypes/TextureAsset.h"
#include "%PROJECT%/Constants.h"
#include "%PROJECT%/Scenes/Frontend.h"

#undef max
#undef min

namespace
{
    void registerComponents()
    {
        %PROJECTLOWER%::buildComponentRegistry();
    }

    void registerAssetBundles()
    {
    }

    void registerTypeHandlers()
    {
    }

    void loadDataAssets()
    {
    }

    void setBgfxSettings()
    {
        bgfx::setViewClear(0, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0x322e3dFF, 1.0f, 0);
        bgfx::setViewClear(%PROJECTLOWER%::constants::render_views::c_geometry, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0x322e3dFF, 1.0f, 0);
    }    
}

class %PROJECT%Game final : public atlas::game::GameImplementation
{
public:
    void OnStartup() override
    {
        using namespace atlas::resource;
        using namespace atlas::scene;

        registerComponents();
        registerTypeHandlers();
        registerAssetBundles();
        loadDataAssets();
        setBgfxSettings();

        m_SceneManager.TransitionTo<%PROJECTLOWER%::scenes::Frontend>();
    }
};

int gameMain(int argc, char* argv[])
{
    atlas::game::GameHost<%PROJECT%Game> game{
        {
            { "%PROJECT%" },
            %PROJECTLOWER%::constants::render_views::c_ui,
            60
        }};
    return game.Run(argc, argv);
}
