lib "%PROJECT%Assets"
    links {
        "SDL",
        "SDLImage",
            
        "tomlcpp",
        "eigen",
        "fixed_string",
        "bgfx",

        "AtlasResource",
    }