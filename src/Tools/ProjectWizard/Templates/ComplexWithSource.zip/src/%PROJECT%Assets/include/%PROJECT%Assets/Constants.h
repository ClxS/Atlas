#pragma once

#include "bgfx/bgfx.h"

namespace %PROJECTLOWER%::constants
{
    namespace render_views
    {
        constexpr bgfx::ViewId c_geometry = 1;
    }

    namespace render_masks
    {        
    }
}
