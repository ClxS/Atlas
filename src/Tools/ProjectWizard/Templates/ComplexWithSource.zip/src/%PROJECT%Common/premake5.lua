lib "%PROJECT%Common"
    links {
        "bgfx",
    }
