lib "%PROJECT%StateFrontend"
    links {
        "AtlasGame",
        "AtlasScene",
    }
