#include "%PROJECT%/Scenes/Frontend.h"

void %PROJECTLOWER%::scenes::Frontend::OnEntered(atlas::scene::SceneManager& sceneManager)
{
    EcsScene::OnEntered(sceneManager);
}

void %PROJECTLOWER%::scenes::Frontend::ConstructSystems(atlas::scene::SystemsBuilder& builder, atlas::scene::SystemsBuilder& frameBuilder)
{
}